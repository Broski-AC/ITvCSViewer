/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hwk3_allison_broski;

import javafx.scene.shape.Rectangle;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.geometry.*;
import javafx.scene.Group;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.StageStyle;

/**
 *
 * @author Allison
 */
public class Hwk3_Allison_Broski extends Application {
    
    //ArrayList to hold the CS and IT degrees. Placed at class level for use in multiple methods
    static ArrayList<String>cSiTDegrees = new ArrayList<String>(); //Prompt 2 and 4
    
    //ArrayList to hold the CS and IT grades. Placed at class level for use in multiple methods
    static ArrayList<String>cSiTGrades = new ArrayList<String>(); //Prompt 2 and 4
    
    //Radio buttons for choosing which type of overview to view.
    RadioButton infoTech; //Prompt 1 and 3
    RadioButton compSci; //Prompt 1 and 3
    
 
    //Prompt 1 - Setting up my primaryStage window
    @Override
    public void start(Stage primaryStage) throws IOException {
        
        //Prompt 1a - Calling the method to fill 2 ArrayLists
        setUpArrayLists();
        
        //Using a GridPane because the assignment doesn't say what to use for this portion
        GridPane mygrid = new GridPane();
        mygrid.setStyle("-fx-background-color: #BAFFC1");
        mygrid.setPadding(new Insets(15, 15, 15, 15));
        mygrid.setHgap(5);
        mygrid.setVgap(5);
        
        //Prompt 1b - Title and two radio buttons
        Text titleText = new Text("Select which type of students to view:");
        mygrid.add(titleText, 2, 1);
        GridPane.setHalignment(titleText, HPos.CENTER);
        GridPane.setValignment(titleText, VPos.TOP);
        mygrid.setAlignment(Pos.TOP_CENTER);
        
        
        //Prompt 1c - Buttons with labels
        //This sets up the ToggleGroup, so that both radio buttons cannot be clicked at the same time.
        ToggleGroup buttonGroup = new ToggleGroup();

        //Radio button for IT students
        infoTech = new RadioButton("View the grades of IT Students");
        infoTech.setSelected(false);
        mygrid.add(infoTech, 1, 2);
        GridPane.setHalignment(infoTech, HPos.LEFT);
        infoTech.setToggleGroup(buttonGroup);
        
        //Prompt 1d - Associate the radio buttons with the same event code            
        infoTech.setOnAction(this::RadioButtonAction);
        
        //Radio button for CS students
        compSci = new RadioButton("View the grades of CS Students");
        compSci.setSelected(false);
        mygrid.add(compSci, 3, 2);
        GridPane.setHalignment(compSci, HPos.RIGHT);
        compSci.setToggleGroup(buttonGroup);
        
        //Prompt 1d - Associate the radio buttons with the same event code 
        compSci.setOnAction(this::RadioButtonAction);

        //Prompt 1e - Show the primaryStage
        Scene knewScene = new Scene(mygrid);
        primaryStage.setTitle("HW3 - IT v CS Viewer");
        primaryStage.setScene(knewScene);
        primaryStage.show();
        
    }

    public static void main(String[] args) {
        launch(args);
    }
    
    //Prompt 2 - filling two ArrayLists
    public static void setUpArrayLists() throws IOException
    {
        //Scanner to read the degrees
        Scanner fileScanner = new Scanner(new File("degree.txt"));
        //Scanner to read the grades
        Scanner fileScanner2 = new Scanner(new File("grades.txt"));
        
        //Prompt 2a - Analyzing the degree file and storing the values in an array.
        while (fileScanner.hasNext()){
            String degree = fileScanner.nextLine();
            cSiTDegrees.add(degree);
        }
        
        //Prompt 2a - Analyzing the grade file and storing the values in an array.
        while (fileScanner2.hasNext()){
            String grade = fileScanner2.nextLine();
            cSiTGrades.add(grade);
        }
    } 
    
    //Prompt 3 - Writing the event handler code to determine which window to open
    public void RadioButtonAction(ActionEvent event){
        //Prompt 3a - Determine which radio button is selected
        if (infoTech.isSelected())
        {
           String iT = "IT";
           displayWindow(iT); //Prompt 3b - Passing the string argument "IT" to the method display Window
        }
        else
        {
            String cS = "CS";
            displayWindow(cS); //Prompt 3b - Passing the string argument "CS"
        }
    }
    
    //Prompt 4
    public static void displayWindow(String degType){
        
        //Initializing the variables to store values for use later on in the code.
        int count = 0;
        int i= 0;
        int aCount = 0;
        int bCount = 0;
        int cCount = 0;
        
        //Prompt 4a and 4b - Run through each item in the cSiTDegrees arraylist
        for (String degResult: cSiTDegrees)
        {
            /*If the string in the cSiTDegrees arraylist matches the degType passed into the method from the radiobutton, then we will consider 
            what to do with it. Otherwise, we will merely increment the index value to check the next relevent spot in cSiT grades arraylist.*/
            if (degResult.equalsIgnoreCase(degType))
                    {
                        //If it matches, increment the number of students that had that degree
                        count++;
                        //Get the object from the cSiTGrades arraylist at the index i that we are currently at.
                        String result = cSiTGrades.get(i);
                        /*Taking the "result" variable from above, we can determine what grade it is equivalent to, then increment the count 
                        for the number of times that grade appears*/
                        switch (result)
                        {
                            case "A":
                                aCount++;
                                break;
                            case "B":
                                bCount++;
                                break;
                            case "C":
                                cCount++;
                                break;         
                        }
                    }
            /*We need to increment i not necessarily for the cSiTDegree list (as that will naturally be run through thanks to the for-each loop, 
            but rather to ensure that the index we are at in the cSiTDegree array is the same index that we are at in the cSiTGrades array.
            If we did not have the same index, the whole point of the program would be mute.
            */
            i++;
        } 
        
        //Prompt 4c - Create a new Group object
        Group root = new Group();
        
        //Prompt 4d - Set the initial X and Y
        int xPosition = 10;//Initial X Position
        int yPosition = 10;//Initial Y Position
        
        //Prompt 4e - Creating the text objects to put on the second stage.
        //Student number level
        Text txtstudentCount = new Text(xPosition, yPosition, "Number of " + degType + " Students in the Program: " + count);
        
        //Remember to add positions
        //Students with A grade
        Text txtaStudent = new Text(10, 50, aCount + " Students had a Grade of A");
        //Students with B grade
        Text txtbStudent = new Text(10, 90, bCount + " Students had a Grade of B");
        //Students with C grade
        Text txtcStudents = new Text(10, 130, cCount + " Students had a Grade of C");
        
        //Prompt 4e - Creating the rectangle objects to put on the second stage.
        //Rectanges to pictorally represent the number of students from each result
        //Student count rectangle
        Rectangle recStudent = new Rectangle(10, 20, count, 10);
        recStudent.setFill(Color.AQUAMARINE);
        //A count rectangle
        Rectangle recaStudent = new Rectangle(10, 60, aCount, 10);
        recaStudent.setFill(Color.CHOCOLATE);
        //B count rectangle
        Rectangle recbStudent = new Rectangle(10, 100, bCount, 10);
        recbStudent.setFill(Color.DARKGREEN);
        //C count rectangle
        Rectangle reccStudent = new Rectangle(10, 140, cCount, 10);
        reccStudent.setFill(Color.MAROON);
        
        //Prompt 4e - Set every object above in the group object
        root.getChildren().addAll(txtstudentCount, recStudent, txtaStudent, recaStudent, txtbStudent,
                recbStudent, txtcStudents, reccStudent);
        
         
        //This is setting up the new window to display the graphs
        Stage resultsStage = new Stage(StageStyle.UTILITY);
        Scene knew = new Scene(root, 350, 160);
        //Prompt 4f - Set the title of the second window
        resultsStage.setTitle(degType + " Student Results");
        resultsStage.setScene(knew);
        //Prompt 4g - Show the second window
        resultsStage.show();
       
        }
}
    
    
    

